-- init.sql: простая схема для упражнений
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  email TEXT
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  price REAL
);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  quantity INTEGER DEFAULT 1,
  order_date TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(product_id) REFERENCES products(id)
);

-- sample data
DELETE FROM users;
DELETE FROM products;
DELETE FROM orders;

INSERT INTO users (id, username, email) VALUES
  (1, 'alice', 'alice@example.com'),
  (2, 'bob', 'bob@example.com'),
  (3, 'carol', 'carol@example.com');

INSERT INTO products (id, name, category, price) VALUES
  (1, 'T-shirt', 'apparel', 19.99),
  (2, 'Mug', 'home', 9.5),
  (3, 'Notebook', 'stationery', 4.99),
  (4, 'Hoodie', 'apparel', 39.99);

INSERT INTO orders (id, user_id, product_id, quantity, order_date) VALUES
  (1, 1, 1, 2, '2025-01-05'),
  (2, 2, 3, 1, '2025-01-10'),
  (3, 1, 2, 1, '2025-02-02'),
  (4, 3, 4, 1, '2025-03-12'),
  (5, 2, 1, 3, '2025-03-15');