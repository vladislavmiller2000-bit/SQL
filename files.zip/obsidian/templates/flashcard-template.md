# Flashcard: {{question_title}}

Q: {{question}}
A: {{answer}}

Теги: #sql #flashcard/{{topic}}