# Exercise: {{title}}

Тема: {{topic}}
Уровень: {{level}}

Описание:
- 

Задачи:
1) 

Файлы:
- exercises/{{id}}.md
- solutions/{{id}}.sql

Как проверять:
- Локально: run scripts/init_db.sh, затем python3 agent/agent.py {{id}}.md