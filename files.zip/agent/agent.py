#!/usr/bin/env python3
"""
Простой локальный "агент" для показа упражнений и проверки SQL-ответов на SQLite.

Поведение:
- Находит файл exercises/*.md (или берет по первому аргументу).
- Показывает текст упражнения.
- Создает временный файл answer.sql и открывает $EDITOR (или читает ввод).
- Выполняет ваш запрос(ы) и эталонный(ые) запрос(ы) из solutions/.
- Сравнивает строки результата (не учитывает порядок: сравнивает множетсво строк).
- Печатает diff-описание.
"""

import os
import sqlite3
import sys
import tempfile
import glob
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "db" / "sqlite.db"
EXERCISES_DIR = ROOT / "exercises"
SOLUTIONS_DIR = ROOT / "solutions"

def choose_exercise():
    md_files = sorted(EXERCISES_DIR.glob("*.md"))
    if not md_files:
        print("No exercises found in", EXERCISES_DIR)
        sys.exit(1)
    if len(sys.argv) > 1:
        candidate = EXERCISES_DIR / sys.argv[1]
        if candidate.exists():
            return candidate
        # allow just name without extension
        candidate2 = EXERCISES_DIR / (sys.argv[1] + ".md")
        if candidate2.exists():
            return candidate2
    import random
    return random.choice(md_files)

def show_exercise(md_path):
    print("="*40)
    print("Exercise:", md_path.name)
    print("-"*40)
    print(md_path.read_text(encoding="utf-8"))
    print("="*40)

def init_db_if_missing():
    if not DB_PATH.exists():
        print("Database not found at", DB_PATH)
        print("Attempting to initialize using db/init.sql...")
        init_sql = ROOT / "db" / "init.sql"
        if not init_sql.exists():
            print("No init.sql found. Please run scripts/init_db.sh or create db/sqlite.db manually.")
            sys.exit(1)
        conn = sqlite3.connect(DB_PATH)
        sql = init_sql.read_text(encoding="utf-8")
        conn.executescript(sql)
        conn.commit()
        conn.close()
        print("Initialized", DB_PATH)

def run_query_get_rows(conn, sql_text):
    cur = conn.cursor()
    try:
        cur.execute(sql_text)
    except Exception as e:
        return {"error": str(e), "rows": None, "columns": None}
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return {"error": None, "rows": rows, "columns": cols}

def compare_results(left, right):
    # left and right are dicts from run_query_get_rows: we compare rows as sets of strings
    if left["error"] or right["error"]:
        return False, left["error"], right["error"]
    set_l = set(tuple(map(str, r)) for r in left["rows"])
    set_r = set(tuple(map(str, r)) for r in right["rows"])
    return set_l == set_r, set_l - set_r, set_r - set_l

def main():
    ex = choose_exercise()
    show_exercise(ex)
    init_db_if_missing()

    # Path to answer file
    tmp_answer = ROOT / ".answer.sql"
    if not tmp_answer.exists():
        tmp_answer.write_text("-- Напишите здесь ваш SQL-ответ и сохраните файл.\n", encoding="utf-8")

    editor = os.environ.get("EDITOR")
    if editor:
        subprocess.run([editor, str(tmp_answer)])
        answer_sql = tmp_answer.read_text(encoding="utf-8")
    else:
        print("EDITOR не задан. Вставьте ваш SQL (завершите пустой строкой):")
        lines = []
        while True:
            line = input()
            if line.strip() == "":
                break
            lines.append(line)
        answer_sql = "\n".join(lines)

    # load solution
    sol_file = SOLUTIONS_DIR / (ex.stem.replace("exercises/", "") + ".sql")
    # try general solution by file name matching exercise name
    alt_sol = SOLUTIONS_DIR / (ex.stem + ".sql")
    if alt_sol.exists():
        sol_file = alt_sol
    if not sol_file.exists():
        # try to find any solution with same prefix
        candidates = list(SOLUTIONS_DIR.glob(ex.stem + "*.sql"))
        sol_file = candidates[0] if candidates else None

    if not sol_file or not sol_file.exists():
        print("No solution found for", ex.name)
        print("You can still execute your SQL against the DB.")
        conn = sqlite3.connect(DB_PATH)
        res = run_query_get_rows(conn, answer_sql)
        if res["error"]:
            print("Error executing your SQL:", res["error"])
        else:
            print("Result columns:", res["columns"])
            for row in res["rows"]:
                print(row)
        conn.close()
        return

    solution_sql = sol_file.read_text(encoding="utf-8")

    conn = sqlite3.connect(DB_PATH)
    user_res = run_query_get_rows(conn, answer_sql)
    sol_res = run_query_get_rows(conn, solution_sql)
    conn.close()

    if user_res["error"]:
        print("Ошибка при выполнении вашего SQL:", user_res["error"])
        return
    if sol_res["error"]:
        print("Ошибка в эталонном SQL (файл решения):", sol_res["error"])
        return

    ok, only_in_user, only_in_solution = compare_results(user_res, sol_res)
    if ok:
        print("Поздравляю! Результаты совпадают с эталоном.")
    else:
        print("Результаты отличаются.")
        if only_in_user:
            print("Строки, которые есть в вашем результате, но нет в эталоне:")
            for r in list(only_in_user)[:20]:
                print(r)
        if only_in_solution:
            print("Строки, которые есть в эталоне, но нет в вашем результате:")
            for r in list(only_in_solution)[:20]:
                print(r)
        print("\nЭталонный запрос (из", sol_file.name, ")\n---\n")
        print(solution_sql)
        print("\nВаш запрос:\n---\n")
        print(answer_sql)

if __name__ == "__main__":
    main()