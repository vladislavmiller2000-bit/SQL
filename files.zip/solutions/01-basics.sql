-- Решение-эталон для сравнения (agent использует это для проверки)

-- 1)
SELECT username, email FROM users ORDER BY username;

-- 2)
SELECT name, category, price FROM products ORDER BY price DESC, name;

-- 3)
SELECT u.username,
       COALESCE(cnt.c, 0) AS orders_count
FROM users u
LEFT JOIN (
  SELECT user_id, COUNT(*) AS c
  FROM orders
  GROUP BY user_id
) cnt ON u.id = cnt.user_id
ORDER BY u.username;