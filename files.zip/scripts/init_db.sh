#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DB="$ROOT/db/sqlite.db"
INIT_SQL="$ROOT/db/init.sql"

if [ ! -f "$INIT_SQL" ]; then
  echo "Не найден $INIT_SQL"
  exit 1
fi

echo "Создаю папку db и инициализирую базу SQLite в $DB"
mkdir -p "$(dirname "$DB")"
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 "$DB" < "$INIT_SQL"
  echo "База создана: $DB"
else
  echo "sqlite3 не установлен. Попробуйте установить sqlite3 или используйте agent/agent.py, который инициализирует базу через Python."
fi